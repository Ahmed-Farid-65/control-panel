import { Chart, registerables } from 'chart.js'; // هنا نستورد الأدوات المطلوبة
Chart.register(...registerables); 

// const chartCanvas= document.getElementById("example-chart");
// const data= JSON.parse(chartCanvas.parentElement.dataset.values);
// const brandColor= (window.getComputedStyle(chartCanvas)).getPropertyValue("--color-brand");
// const chart= new Chart(chartCanvas, {
//     type: 'line',
//     data: {
//         labels:["يناير ","فبراير ","مارس ","ابريل  ","مايو ","يونيو ","يوليو ","أغسطس ","سبتمبر ","أكتوبر ","نوفمبر ","ديسمبر "],
//         datasets: [{
//             label: "مبيعات الشهر",
//             data: data,
//             borderColor: brandColor,
//             backgroundColor: "transparent",
//             lineTension: 0.2
//         }]
//     },
//     options: {
//         legend: {
//             display: false
//         },
//         scales : { 
//             yAxes: [{
//                 display:false
//             }],
//             xAxes: [{
//                 position: "top"
//             }],
//         }
//     }
// })

(function(){
    // const ctx = document.getElementById('example-chart');

    // new Chart(ctx, {
    // type: 'bar',
    // data: {
    //     labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    //     datasets: [{
    //     label: '# of Votes',
    //     data: [12, 19, 3, 5, 2, 3],
    //     borderWidth: 1
    //     }]
    // },
    // options: {
    //     scales: {
    //     y: {
    //             beginAtZero: true
    //         }
    //     }
    //     }
    // });



    const chartCanvas= document.getElementById("example-chart");
    const data= JSON.parse(chartCanvas.parentElement.dataset.values);
    const brandColor= (window.getComputedStyle(chartCanvas)).getPropertyValue("--color-brand");
    const chart= new Chart(chartCanvas, {
        type: 'line',
        data: {
            labels:["يناير ","فبراير ","مارس ","ابريل  ","مايو ","يونيو ","يوليو ","أغسطس ","سبتمبر ","أكتوبر ","نوفمبر ","ديسمبر "],
            datasets: [{
                label: "مبيعات الشهر",
                data: data,
                borderColor: brandColor,
                backgroundColor: "transparent",
                lineTension: 0.2
            }]
        },
        options: {
            legend: {
                display: false
            },
            scales : { 
                yAxes: [{
                    display:false
                }],
                xAxes: [{
                    position: "top"
                }],
            }
        }
    });
    
    const navigation= document.querySelector(".c-table__navigation");
    const randomArray= (lenght,max) => [ ... new Array(lenght)].map(() => Math.round(Math.random()*max));
    navigation.addEventListener("click",() => {
        chart.data.datasets[0].data= randomArray(12,1200);
        chart.update();
    })
})();